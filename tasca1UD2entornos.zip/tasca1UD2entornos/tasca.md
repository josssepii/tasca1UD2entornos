## TASCA 1

> **1. En la funció 1… Què fan aquestes línies de codi?**

**substring(0, string2.length()-1)**  
Esta línea hace que string2 pierda su último valor, en este  caso el 2.  

**string2=string2+"1"**  
Esta otra línea añade un 1 al final.  

string2 pasaría a ser finalmente string1. O cualquier valor que tuviese string.  
Por ejemplo si la variable string2 fuese hola, se quitaría la a (hol) y se añadiría  
un 1 (hol1).

> **2. Què valen les variables string1 i string2 abans d'executar el codi de comprovació següent?**
 
string1 ya valía de por sí string1 y con las líneas de código anteriores string2 pasaba  
a ser string1 también, por lo cual el código donde los compara con un == dará como  
resultado que son iguales.

> **3. Per què no funciona l'operador == ? Quin operador s'ha d'usar en lloc d'aquest?**
 
Cuando escribimos strings no se usa == se usa .equals(), por eso el código dará error.

> **4. La función2() està declarada com segueix. Aquesta funció com l'he de cridar des del mètode MAIN perquè funcione. Existeixen 2
possibilitats. Explica-les.**
 
Delante de void podríamos añadir un static de forma que quede así: public static void funcion2().  
Así podemos llamar directamente desde el main.

La otra forma sería crear un objeto y llamar la función desde el. 